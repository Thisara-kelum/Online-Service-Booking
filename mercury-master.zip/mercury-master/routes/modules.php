<?php

use Illuminate\Support\Facades\Route;

Route::group([], base_path('modules/Core/routes.php'));
