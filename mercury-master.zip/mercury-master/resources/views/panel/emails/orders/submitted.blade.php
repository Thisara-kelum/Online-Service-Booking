@extends('layouts.email')

@section('head')

@endsection

@section('body')
    <h2>Yeni Sipariş Aldınız</h2>
@endsection
