<footer class="footer mt-auto">
    <div class="copyright bg-white">
        <p>
            <!-- &copy; {{ date('Y') }} <a href="https://phobos.berkaycubuk.com" target="_blank">Mercury Panel</a> v{{ env('PHOBOS_VERSION') }}<br/><br/> -->
            <a href="https://berkaycubuk.com">Mercury E-ticaret Sistemi</a> {{ env('SELF_UPDATER_VERSION_INSTALLED') }}
        </p>
    </div>
</footer>
