<?php

return [
    'delete_product_msg' => 'Bu ürünü kalıcı olarak silmek istediğinize emin misiniz ?',
    'delete_category_msg' => 'Bu ürün kategorisini kalıcı olarak silmek istediğinize emin misiniz ?',
    'delete_subcategory_msg' => 'Bu ürün kategorisini kalıcı olarak silmek istediğinize emin misiniz ?',
];
