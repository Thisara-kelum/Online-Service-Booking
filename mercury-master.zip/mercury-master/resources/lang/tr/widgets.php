<?php

return [
    'todays_new_users' => [
        'title' => 'Bugünkü Yeni Üyeler',
    ],
    'todays_visitors' => [
        'title' => 'Bugünkü Ziyaretçiler',
    ],
    'todays_orders' => [
        'title' => 'Bugünkü Siparişler',
    ],
    'todays_payments' => [
        'title' => 'Bugünkü Satış Miktarı',
    ],
];
