<div class="action-holder">
    @include('core::partials.actions.darkmode')
</div>
