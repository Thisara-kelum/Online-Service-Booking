<div class="darkmode-action" onclick="toggleDarkmode()" tabindex="0">
    <svg fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.353 3C5.849 4.408 3 7.463 3 11.47A9.53 9.53 0 0012.53 21c4.007 0 7.062-2.849 8.47-6.353C8.17 17.065 8.14 8.14 9.353 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
