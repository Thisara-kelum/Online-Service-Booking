<section class="site-badges container">
    <div class="site-badge">
        @include('core::svg.lock')
        <!-- <img src="{{ asset('assets/store/img/lock.svg') }}" /> -->
        <span>GÜVENLİ ALIŞVERİŞ</span>
    </div>
    <div class="site-badge">
        @include('core::svg.discount')
        <!-- <img src="{{ asset('assets/store/img/percent.svg') }}" /> -->
        <span>ÖZEL FIRSATLAR</span>
    </div>
    <div class="site-badge">
        @include('core::svg.truck')
        <!-- <img src="{{ asset('assets/store/img/truck-loading.svg') }}" /> -->
        <span>100₺ VE ÜZERİ ÜCRETSİZ KARGO</span>
    </div>
    <div class="site-badge">
        @include('core::svg.gift')
        <!-- <img src="{{ asset('assets/store/img/gift.svg') }}" /> -->
        <span>HEDİYE PAKETLEMESİ</span>
    </div>
</section>
