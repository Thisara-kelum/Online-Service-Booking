<div class="loading">
    <div class="loading-thing"></div>
    <div class="loading-thing loading-thing-secondary"></div>
</div>
