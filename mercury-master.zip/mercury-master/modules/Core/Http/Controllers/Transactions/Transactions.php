<?php

namespace Core\Http\Controllers\Transactions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Core\Models\Transaction;

class Transactions extends Controller
{
}
