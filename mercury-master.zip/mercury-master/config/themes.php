<?php

return [
    'themes' => [
        'default' => [
            'views_path' => 'resources/themes/default/views',
            'assets_path' => 'themes/default/assets',
            'name' => 'default',
        ]
    ]
];
